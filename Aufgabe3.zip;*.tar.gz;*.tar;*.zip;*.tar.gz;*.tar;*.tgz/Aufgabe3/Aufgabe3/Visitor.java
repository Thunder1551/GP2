package gp2.h1.ex3_visitor;

/**
 * Interface of a visitor for Tree objects (Visitor design pattern).
 * 
 */
public interface Visitor {

	// TODO declare method for visiting a node

}
