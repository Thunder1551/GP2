package heim02;

/**
 * @author Julia Kraemer juliadk@mail.uni-paderborn.de
 * @since 09.04.15
 */
public abstract class Blume {

    public abstract void setPreis(double preis);
    public abstract void setFarbe(Farbe farbe);
    public abstract void setBluetezeit(int bluetezeit);
}
