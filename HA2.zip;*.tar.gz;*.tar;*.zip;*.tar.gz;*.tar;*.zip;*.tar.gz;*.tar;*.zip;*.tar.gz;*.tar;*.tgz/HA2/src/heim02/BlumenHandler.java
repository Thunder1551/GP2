package heim02;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class BlumenHandler extends DefaultHandler {

	private Blumenladen bLaden;
	private Blume blume;
	String text ;

	public Blumenladen getBlumenLaden() {

		return this.bLaden;
	}

	@Override
	public void startDocument() throws SAXException {
		this.bLaden = new Blumenladen();
	}

	@Override
	public void startElement(String uri, String localName, String qName,
			Attributes attributes) throws SAXException {
		if (qName.equals("tulpe")) {
			blume = new Tulpe();
		}
		if (qName.equals("rose")) {
			blume = new Rose();
		}
		if (qName.equals("narzisse")) {
			blume = new Narzisse();
		}
		
		
	}

	@Override
	public void endElement(String uri, String localName, String qName)
			throws SAXException {
		if (qName.equals("tulpe") || qName.equals("rose") || qName.equals("narzisse")){
			bLaden.addBlume(blume);
		}
		if(qName.equals("farbe")){
			String s = text.toUpperCase();
			Farbe f = Farbe.valueOf(s);
			blume.setFarbe(f);
		}
		if(qName.equals("bluetezeit")){
			blume.setBluetezeit(Integer.parseInt(text));
		}
		if(qName.equals("preis")){
			blume.setPreis(Double.parseDouble(text));
		}
		
	}

	@Override
	public void characters(char[] ch, int start, int length)
			throws SAXException {
		text = String.valueOf(ch, start, length);
		
	}

}
