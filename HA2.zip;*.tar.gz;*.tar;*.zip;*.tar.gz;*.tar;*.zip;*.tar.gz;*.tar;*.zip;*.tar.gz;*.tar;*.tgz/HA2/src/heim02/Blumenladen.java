package heim02;

import java.util.LinkedList;

/**
 * @author Julia Kraemer juliadk@mail.uni-paderborn.de
 * @since 09.04.15
 */
public class Blumenladen {

    //Liste, um alle vorhandenen Blumen im Laden zu speichern
    private LinkedList<Blume> blumenbestand;

    public Blumenladen(){
        blumenbestand = new LinkedList<Blume>();
    }

    //Methode um eine Blume dem Blumenbestand hinzuzufuegen
    public void addBlume(Blume b){
        blumenbestand.add(b);
    }

    //Methode, um eine Blume aus dem Blumenbestand zu loeschen
    public void removeBlume(Blume b){
        blumenbestand.remove(b);
    }


    @Override
    public String toString(){
        return blumenbestand.toString();
    }
}
