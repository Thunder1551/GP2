package heim02;

/**
 * @author Julia Kraemer juliadk@mail.uni-paderborn.de
 * @since 09.04.15
 */
public enum Farbe {
    ROT,ORANGE,WEISS,GELB,ROSA
}
