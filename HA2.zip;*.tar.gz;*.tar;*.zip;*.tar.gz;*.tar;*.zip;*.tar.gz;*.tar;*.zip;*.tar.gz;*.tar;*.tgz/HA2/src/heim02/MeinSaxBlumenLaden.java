package heim02;

import java.io.File;
import java.util.ArrayList;
import java.util.Scanner;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

public class MeinSaxBlumenLaden {

	public static void main(String[] args) throws Exception {
		ArrayList<File> input = new ArrayList<File>();
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter file Pfad ( Enter f to end ) : ");
		String s = "";
		while (!s.equals("f") && sc.hasNext()) {
			s = sc.next();
			if (!s.equals("f")) {
				File fileP1 = new File(s);
				input.add(fileP1);

			} else {
				sc.close();
			}

		}

		// int i =0;
		// do{
		// String s = sc.nextLine();
		// if (!s.equals("f")) {
		// fileP = new File(s);
		// input.add(fileP);
		// }
		// else{sc.close();}
		// }while(i < 3);

		SAXParserFactory factory = SAXParserFactory.newInstance();
		SAXParser saxParser = factory.newSAXParser();
		BlumenHandler blumenHandler = new BlumenHandler();
		for (File f : input) {
			saxParser.parse(f, blumenHandler);
			Blumenladen bLaden = blumenHandler.getBlumenLaden();
			System.out.println(bLaden.toString());
			System.err.println("next : ");
		}

		System.out.println("finish ! ");
		// System.out.println(Farbe.GELB.toString());
		// System.out.println(Farbe.valueOf("ROSA"));

	}
}
