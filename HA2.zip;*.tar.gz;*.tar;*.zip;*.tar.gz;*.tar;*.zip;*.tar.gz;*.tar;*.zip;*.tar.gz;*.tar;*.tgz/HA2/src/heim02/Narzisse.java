package heim02;

/**
 * @author Julia Kraemer juliadk@mail.uni-paderborn.de
 * @since 09.04.15
 */
public class Narzisse extends Blume {

    //Felder um die Werte fuer Preis, Bluetezeit und Farbe zu speichern
    private static final double preis = 1;
    private Farbe farbe;
    private int bluetezeit;

    /**
     *
     * @param farbe Farbe, die die Narzisse haben soll
     * @param bluetezeit Zeit (in Wochen), in der die Narzisse bluehen soll
     */
    public Narzisse(Farbe farbe, int bluetezeit){
        this.farbe=farbe;
        this.bluetezeit=bluetezeit;
    }

    public Narzisse(){

    }


    public void setPreis(double preis){

    }


    public void setFarbe(Farbe farbe) {
        this.farbe = farbe;
    }


    public void setBluetezeit(int bluetezeit) {
        this.bluetezeit = bluetezeit;
    }

    public String toString(){
        return "Narzisse(" + farbe + "," + preis + "," + bluetezeit + ")";
    }

}
