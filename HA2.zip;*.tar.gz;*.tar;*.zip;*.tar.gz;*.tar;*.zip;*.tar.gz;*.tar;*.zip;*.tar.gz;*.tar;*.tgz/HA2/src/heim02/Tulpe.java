package heim02;

/**
 * @author Julia Kraemer juliadk@mail.uni-paderborn.de
 * @since 09.04.15
 */
public class Tulpe extends Blume{

    //Felder um die Werte fuer Preis, Bluetezeit und Farbe zu speichern
    private double preis = 1;
    private Farbe farbe;
    private int bluetezeit;

    /**
     *
     * @param farbe Farbe, die die Tulpe haben soll
     * @param bluetezeit Zeit (in Wochen), in der die Tulpe bluehen soll
     * @param preis Preis, zu dem die Tulpe verkauft werden soll
     */
    public Tulpe(Farbe farbe, int bluetezeit, double preis){
        this.farbe=farbe;
        this.bluetezeit=bluetezeit;
        this.preis=preis;
    }

    public Tulpe(){

    }

    public void setPreis(double preis){
        this.preis = preis;
    }


    public void setFarbe(Farbe farbe) {
        this.farbe = farbe;
    }


    public void setBluetezeit(int bluetezeit) {
        this.bluetezeit = bluetezeit;
    }

    public String toString(){
        return "Tulpe(" + farbe + "," + preis + "," + bluetezeit + ")";
    }
}
